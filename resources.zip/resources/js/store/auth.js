// resources/js/store/auth.js

import axios from 'axios';
import router from '@/router';
import store from '@/store';

export default {
  namespaced: true,
  state: {
    authenticated: false,
    user: null,
    authorization: {},
    userRole: null,
    authError: null,
  },
  getters: {
    authenticated(state) {
      return state.authenticated;
    },
    user(state) {
      return state.user;
    },
    userRole(state) {
      return state.userRole;
    },
    userProfile(state) {
      return state.user?.profile || {};
    },
    authError(state) {
      return state.authError;
    },
  },
  mutations: {
    SET_AUTHENTICATED(state, value) {
      state.authenticated = value;
    },
    SET_USER(state, value) {
      state.user = value;
      state.userRole = value.role;
    },
    SET_TOKEN(state, value) {
      state.authorization = value;
    },
    CLEAR_USER(state) {
      state.user = null;
      state.userRole = null;
      state.authorization = {};
    },
    SET_USER_ROLE(state, value) {
      state.userRole = value;
    },
    SET_AUTH_ERROR(state, error) {
      state.authError = error;
    },
  },
  actions: {
    /**
     * Initialize the authentication state from localStorage or perform a session check.
     */
    async initialize({ commit }) {
      const localUser = localStorage.getItem('user');
      if (localUser) {
        try {
          const data = JSON.parse(localUser);
          if (data.data && data.data.user && data.authorization && data.authorization.token) {
            commit('SET_USER', data.data.user);
            commit('SET_AUTHENTICATED', true);
            commit('SET_TOKEN', data.authorization);
            commit('SET_USER_ROLE', data.data.user.role);

            // Set the Authorization header for future requests
            axios.defaults.headers.common['Authorization'] = `Bearer ${data.authorization.token}`;
          } else {
            throw new Error('Invalid user data structure');
          }
        } catch (error) {
          console.error('Error parsing user data from localStorage:', error);
          commit('CLEAR_USER');
        }
      } else {
        try {
          // Example API call to verify session status
          const { data } = await axios.get('/api/user/session-check');
          if (data && data.user && data.token) {
            const storedData = {
              data: {
                user: data.user,
              },
              authorization: {
                token: data.token,
              },
            };
            localStorage.setItem('user', JSON.stringify(storedData));
            commit('SET_USER', data.user);
            commit('SET_AUTHENTICATED', true);
            commit('SET_TOKEN', { token: data.token });
            commit('SET_USER_ROLE', data.user.role);
            axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
          } else {
            commit('CLEAR_USER');
          }
        } catch (error) {
          console.error('Session check failed:', error);
          commit('CLEAR_USER');
        }
      }
    },

    /**
     * Login using user credentials.
     * @param {Object} credentials - User credentials (e.g., username and password).
     */
    async login({ commit }, credentials) {
      try {
        const { data } = await axios.post('/api/user/login', credentials);
        if (data && data.data && data.data.user && data.authorization && data.authorization.token) {
          // Store user data in localStorage
          localStorage.setItem("user", JSON.stringify(data));
          commit('SET_USER', data.data.user);
          commit('SET_AUTHENTICATED', true);
          commit('SET_TOKEN', data.authorization);
          commit('SET_USER_ROLE', data.data.user.role);
          axios.defaults.headers.common['Authorization'] = `Bearer ${data.authorization.token}`;

          // Set the token in a cookie
          // Note: 'HttpOnly' cannot be set via JavaScript. It must be set server-side.
          // Below is an example without 'HttpOnly'. For enhanced security, set cookies on the server.
          //document.cookie = `token=${data.authorization.token}; path=/; domain=connectyed.com; secure; samesite=lax;`;

          const rolePathMap = {
            'admin': '/admin/dashboard',
            'matchmaker': '/matchmaker/dashboard',
            'candidate': '/client/dashboard',
            'client': '/client/dashboard',
          };
          const rolePath = rolePathMap[data.data.user.role] || '/';
          router.push({ path: rolePath });
        } else {
          throw new Error('Invalid login response structure');
        }
      } catch (error) {
        commit('CLEAR_USER');
        commit('SET_AUTHENTICATED', false);
        commit('SET_AUTH_ERROR', error.response?.data.message || 'Login failed');
        console.error('Login error:', error.response?.data || error.message || error);

        // Throw the error to be handled in the component
        throw error;
      }
    },

    /**
     * Register a new user.
     * @param {Object} userData - User registration data.
     */
    async register({ commit }, userData) {
      try {
        const response = await axios.post('/api/user/register', userData);
        if (response.data.success === true) {
          // Registration successful
          return response.data;
        } else {
          // Handle registration failure
          throw new Error(response.data.message || 'Registration failed');
        }
      } catch (error) {
        // Re-throw the error to be handled in the component
        throw error;
      }
    },

    /**
     * Logout the user by clearing the authentication state and redirecting to login.
     */
    logout({ commit }) {
      commit('CLEAR_USER');
      commit('SET_AUTHENTICATED', false);
      localStorage.removeItem("user");
      localStorage.removeItem("vuex");
      delete axios.defaults.headers.common['Authorization'];

      // Clear the token cookie by setting its expiration to the past
      document.cookie = `token=; path=/; domain=connectyed.com; secure; samesite=lax; expires=Thu, 01 Jan 1970 00:00:00 GMT`;

      router.push({ path: '/login' });
    },

    /**
     * Set authentication state directly (used for OAuth callbacks).
     * @param {Object} payload - Contains user data and authorization token.
     */
    setAuth({ commit }, payload) {
      try {
        if (payload.user && payload.authorization && payload.authorization.token) {
          const storedData = {
            data: { user: payload.user },
            authorization: payload.authorization,
          };
          localStorage.setItem("user", JSON.stringify(storedData));
          commit('SET_USER', payload.user);
          commit('SET_AUTHENTICATED', true);
          commit('SET_TOKEN', payload.authorization);
          commit('SET_USER_ROLE', payload.user.role);
          axios.defaults.headers.common['Authorization'] = `Bearer ${payload.authorization.token}`;

          // Set the token in a cookie
          document.cookie = `token=${payload.authorization.token}; path=/; domain=connectyed.com; secure; samesite=lax`;
        } else {
          throw new Error('Invalid payload structure for setAuth');
        }
      } catch (error) {
        console.error('Error setting authentication state:', error);
        commit('CLEAR_USER');
      }
    },
  }
};

// Axios interceptor to auto-logout on 401 errors
axios.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      store.dispatch('auth/logout');
    }
    return Promise.reject(error);
  }
);
