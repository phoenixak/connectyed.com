<template>
    <div>
      <h2 class="text-xl font-bold mb-4">OVerview</h2>
      <!-- Insert Dashboard Overview content here -->
      <p>OVerview!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: "overview",
  };
  </script>
  