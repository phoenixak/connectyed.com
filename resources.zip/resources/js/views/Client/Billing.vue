<template>
    <div class="container mx-auto p-4">
      <h2 class="text-xl font-bold mb-4">Dating Packages</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div v-for="product in products" :key="product.id" class="bg-white p-6 rounded-lg shadow">
          <h3 class="text-lg font-semibold mb-2">{{ product.name }}</h3>
          <p class="text-gray-700 mb-4">{{ product.description }}</p>
          <p class="text-xl font-bold mb-4">${{ (product.price / 100).toFixed(2) }}</p>
          <button
            @click="openDiscountModal(product)"
            :disabled="processing"
            class="w-full py-2 px-4 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200 disabled:bg-blue-300"
            aria-label="Purchase {{ product.name }}"
          >
            <span v-if="processing">Processing...</span>
            <span v-else>Purchase</span>
          </button>
        </div>
      </div>

      <!-- Discount Code Modal -->
      <div v-if="showDiscountModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded-lg shadow-lg w-80">
          <h3 class="text-lg font-semibold mb-4">Enter Discount Code</h3>
          <input
            v-model="discountCode"
            type="text"
            placeholder="Discount Code"
            class="w-full px-3 py-2 border rounded mb-4"
            aria-label="Discount Code"
          />
          <div class="flex justify-end">
            <button
              @click="closeDiscountModal"
              class="mr-2 px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
            <button
              @click="confirmPurchase"
              :disabled="processing"
              class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200 disabled:bg-blue-300"
            >
              <span v-if="processing">Processing...</span>
              <span v-else>Confirm</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </template>

  <script>
  import axios from 'axios';
  import { mapState } from 'vuex';

  export default {
    name: "Billing",
    data() {
      return {
        products: [
          {
            id: 'tier1',
            name: 'Tier 1 Dating Package',
            description: 'A matchmaker sends the date for a 1 on 1 date with profile of the date with 1 photo (all other images blurry) and Description and Details are blurry',
            price: 5000, // in cents ($50)
            stripePriceId: 'price_1Q8q4aFZef913bMWUE3mWRF2',
          },
          {
            id: 'tier2',
            name: 'Tier 2 Dating Package',
            description: 'Date has all images and all profile details',
            price: 10000, // in cents ($100)
            stripePriceId: 'price_1Q8q5IFZef913bMWHVXb99st',
          },
          {
            id: 'tier3',
            name: 'Tier 3 Dating Package',
            description: 'Date has all images and profile details (client picks 1 of 2 date options)',
            price: 17500, // in cents ($175)
            stripePriceId: 'price_1Q8q89FZef913bMW1D2pUPso',
          },
        ],
        processing: false,
        showDiscountModal: false,
        selectedProduct: null,
        discountCode: '',
      };
    },
    computed: {
      ...mapState({
        user: state => state.auth.user.user,
        authorization: state => state.auth.authorization,
      }),
    },
    methods: {
      openDiscountModal(product) {
        this.selectedProduct = product;
        this.showDiscountModal = true;
      },
      closeDiscountModal() {
        this.showDiscountModal = false;
        this.selectedProduct = null;
        this.discountCode = '';
      },
      async confirmPurchase() {
        if (!this.selectedProduct) return;

        this.processing = true;
        try {
          const payload = {
            product_type: this.selectedProduct.id,
            price_id: this.selectedProduct.stripePriceId,
            discount_code: this.discountCode || null,
            // Include additional fields if necessary
          };

          const response = await axios.post(
            '/api/billing/create-checkout-session',
            payload,
            {
              headers: {
                Authorization: `Bearer ${this.authorization.token}`,
              },
            }
          );

          if (response.data.success) {
            const { checkout_url } = response.data;
            window.location.href = checkout_url;
          } else {
            console.error('Failed to create checkout session:', response.data.message);
            alert(response.data.message || 'Failed to create checkout session. Please try again.');
          }
        } catch (error) {
          console.error('Error creating checkout session:', error);
          if (error.response && error.response.data && error.response.data.message) {
            alert(`Error: ${error.response.data.message}`);
          } else {
            alert('An unexpected error occurred. Please try again later.');
          }
        } finally {
          this.processing = false;
          this.closeDiscountModal();
        }
      },
    },
  };
  </script>

  <style scoped>
  /* Optional: Add any necessary styling here */
  </style>
