<template>
    <div>
      <h2 class="text-xl font-bold mb-4">Messages</h2>
      <!-- Insert Dashboard Overview content here -->
      <p>Messages!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: "message",
  };
  </script>
  