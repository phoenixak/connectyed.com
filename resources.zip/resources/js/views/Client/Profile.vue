<template>
    <div class="mx-full shadow-connectyed rounded-xl bg-connectyed-card-light flex flex-col py-5 px-5 mb-5">
        <div class="grid grid-cols-4 gap-4">
            <label class="text-lg font-bold text-gray-900 dark:text-white mb-4 p-2">About your Profile</label>
            <span></span>
            <span></span>
            <button
                class="bg-connectyed-button-light text-connectyed-button-dark py-3 px-10"
                @click="toggleFormVisibility"
                v-if="!isFormVisible"
            >
                Edit Info
            </button>
        </div>

        <!-- Loading State -->
        <div v-if="!user || !profile" class="text-center my-5">
            <p class="text-gray-700">Loading user and profile information...</p>
        </div>

        <!-- Main Content -->
        <div class="main-content" v-else>
            <!-- Profile Display -->
            <div v-if="!isFormVisible">
                <div class="flex">
                    <!-- Profile Images Section -->
                    <div class="col-4 p-2">
                        <div class="flex flex-wrap justify-left cursor-pointer">
                            <!-- Main Image -->
                            <div class="w-[270px] h-[360px] overflow-hidden bg-gray-400" v-if="!currentAvatar">
                                <img src="upload/images/profiles/default.png" alt="Main Image" class="w-full h-full object-cover">
                            </div>

                            <div class="w-[270px] h-[360px] overflow-hidden bg-gray-400" v-if="currentAvatar">
                                <img :src="currentAvatar" alt="Main Image" class="w-full h-full object-cover">
                            </div>

                            <!-- Thumbnails -->
                            <div class="flex flex-wrap justify-left gap-1/2 mt-2">
                                <div
                                    class="w-[45px] h-[61px] p-1 overflow-hidden cursor-pointer"
                                    v-for="(image, index) in userImages"
                                    :key="index"
                                >
                                    <img
                                        :src="image"
                                        @click="updateAvatar(image)"
                                        alt="Profile Thumbnail"
                                        class="shadow-sm bg-gray-400 w-full h-full object-cover rounded"
                                    >
                                </div>
                            </div>
                        </div>

                        <!-- Upload Image Button -->
                        <div class="flex w-full my-2">
                            <label for="file_upload" class="cursor-pointer w-full flex">
                                <span class="text-connectyed-button-dark bg-connectyed-button-light hover:bg-connectyed-button-hover
                                hover:text-connectyed-button-hover-dark focus:outline-none focus:ring-2 focus:ring-blue-500 px-4 py-2 w-full
                                justify-center text-center rounded">
                                    Upload Image
                                </span>
                                <input
                                    type="file"
                                    id="file_upload"
                                    class="hidden"
                                    @change="uploadFile"
                                />
                            </label>
                        </div>
                    </div>

                    <!-- Profile Details Section -->
                    <div class="col-7">
                        <!-- User Name -->
                        <div class="flex flex-wrap mb-1">
                            <div class="w-full">
                                <label class="text-gray-700 text-2xl font-semibold">
                                    {{ user.name }}
                                </label>
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="flex flex-wrap mb-1">
                            <div class="w-full">
                                <label class="text-gray-700 text-2xl">
                                    {{ profile.city || 'Your City' }}, {{ profile.country || 'Your Country' }}
                                </label>
                            </div>
                        </div>

                        <!-- Additional Profile Information -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Location:
                                </label>
                                <span>{{ profile.location || 'Your current location / City' }}</span>
                            </div>
                        </div>

                        <!-- Age -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Age:
                                </label>
                                <span>{{ profile.age || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Gender -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Gender:
                                </label>
                                <span>{{ profile.gender || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Body Type and Height -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-1/2">
                                <label class="text-gray-700 text-md font-medium">
                                    Body Type:
                                </label>
                                <span>{{ profile.bodytype || 'N/A' }}</span>
                            </div>
                            <div class="w-1/2">
                                <label class="text-gray-700 text-md font-medium">
                                    Height:
                                </label>
                                <span>
                                    {{ profile.height ? profile.height + '′' : 'N/A' }}
                                    {{ profile.inches ? profile.inches + '″' : '0″' }}
                                </span>
                            </div>
                        </div>

                        <!-- Hair Color -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Hair Color:
                                </label>
                                <span>{{ profile.haircolor || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Marital Status -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Marital Status:
                                </label>
                                <span>{{ profile.maritalstatus || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Children -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Children:
                                </label>
                                <span>{{ profile.children || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Religion -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Religion:
                                </label>
                                <span>{{ profile.religion || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Smoker and Drinker -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-1/2">
                                <label class="text-gray-700 text-md font-medium">
                                    Smoker:
                                </label>
                                <span>{{ profile.smoker || 'N/A' }}</span>
                            </div>
                            <div class="w-1/2">
                                <label class="text-gray-700 text-md font-medium">
                                    Drinker:
                                </label>
                                <span>{{ profile.drinker || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Education -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Education:
                                </label>
                                <span>{{ profile.education || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Job Title -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Job Title:
                                </label>
                                <span>{{ profile.jobtitle || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Sports -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Sports:
                                </label>
                                <span>{{ profile.sports || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Hobbies -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Hobbies:
                                </label>
                                <span>{{ profile.hobbies || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- English Level -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    English Level:
                                </label>
                                <span>{{ profile.english || 'N/A' }}</span>
                            </div>
                        </div>

                        <!-- Languages -->
                        <div class="flex flex-wrap mb-3">
                            <div class="w-full">
                                <label class="text-gray-700 text-md font-medium">
                                    Languages:
                                </label>
                                <span>{{ profile.languages || 'N/A' }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Self Description -->
                <div class="grid grid-cols-1 px-4 min-h-16 mb-3">
                    <label class="text-gray-700 text-md font-medium">
                        Self Description:
                    </label>
                    <p class="text-gray-600">{{ profile.description || 'N/A' }}</p>
                </div>

                <!-- Comments -->
                <div class="grid grid-cols-1 px-4 min-h-16">
                    <label class="text-gray-700 text-md font-medium">
                        Comments:
                    </label>
                    <p class="text-gray-600">{{ profile.comment || 'N/A' }}</p>
                </div>
            </div>

            <!-- Edit Form -->
            <div v-if="isFormVisible">
                <form class="w-full" @submit.prevent="postProfile" method="put">
                    <!-- Full Name -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="name">
                                Full Name
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white"
                                type="text"
                                v-model="user.name"
                                id="name"
                                required
                            >
                        </div>
                    </div>

                    <!-- City and State -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- City -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="city">
                                City
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.city"
                                id="city"
                                type="text"
                                required
                            >
                        </div>

                        <!-- State -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="state">
                                State
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.state"
                                id="state"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- Country -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="country">
                                Country
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.country"
                                    id="country"
                                    required
                                >
                                    <option value="">Select Country</option>
                                    <option value="United States of America">United States of America</option>
                                    <option value="Canada">Canada</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Current Location -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="location">
                                Current Location (City)
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.location"
                                id="location"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- Age and Hair Color -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Age -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="age">
                                Age
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.age"
                                id="age"
                                type="number"
                                min="0"
                                required
                            >
                        </div>

                        <!-- Hair Color -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="haircolor">
                                Hair Color
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.haircolor"
                                id="haircolor"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- Gender -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="gender">
                            Gender
                        </label>
                        <div class="relative w-full">
                            <select
                                class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.gender"
                                id="gender"
                                required
                            >
                                <option value="">Select Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <!-- Body Type, Height Feet, and Inches -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Body Type -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="bodytype">
                                Body Type
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.bodytype"
                                    id="bodytype"
                                    required
                                >
                                    <option value="">Select Body Type</option>
                                    <option>Slender</option>
                                    <option>Average</option>
                                    <option>Athletic</option>
                                    <option>Curvy</option>
                                    <option>Big and Beautiful</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <!-- Height (Feet) -->
                        <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="height">
                                Height (Feet)
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.height"
                                id="height"
                                placeholder="0"
                                min="0"
                                max="8"
                                type="number"
                                required
                            >
                        </div>

                        <!-- Height (Inches) -->
                        <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="inches">
                                Inches
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.inches"
                                id="inches"
                                placeholder="0"
                                min="0"
                                max="11"
                                type="number"
                                required
                            >
                        </div>
                    </div>

                    <!-- Marital Status and Children -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Marital Status -->
                        <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="maritalstatus">
                                Marital Status
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.maritalstatus"
                                    id="maritalstatus"
                                    required
                                >
                                    <option value="">Select Status</option>
                                    <option>Single</option>
                                    <option>Separated</option>
                                    <option>Divorced</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <!-- Children -->
                        <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="children">
                                Children
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.children"
                                    id="children"
                                    required
                                >
                                    <option value="">Select Number</option>
                                    <option>0</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <!-- Religion -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="religion">
                                Religion
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.religion"
                                    id="religion"
                                    required
                                >
                                    <option value="">Select Religion</option>
                                    <option>Baha'i</option>
                                    <option>Buddhism</option>
                                    <option>Catholic</option>
                                    <option>Christian</option>
                                    <option>Confucianism</option>
                                    <option>Hinduism</option>
                                    <option>Islam</option>
                                    <option>Jainism</option>
                                    <option>Judaism</option>
                                    <option>Shinto</option>
                                    <option>Sikhism</option>
                                    <option>Taoism</option>
                                    <option>Zoroastrianism</option>
                                    <option>Other</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Smoker and Drinker -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Smoker -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="smoker">
                                Smoker
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.smoker"
                                    id="smoker"
                                    required
                                >
                                    <option value="">Select Option</option>
                                    <option>Yes</option>
                                    <option>No</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <!-- Drinker -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="drinker">
                                Drinker
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.drinker"
                                    id="drinker"
                                    required
                                >
                                    <option value="">Select Option</option>
                                    <option>None</option>
                                    <option>Occasionally</option>
                                    <option>Often</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Education and Job Title -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Education -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="education">
                                Education
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.education"
                                id="education"
                                type="text"
                                required
                            >
                        </div>

                        <!-- Job Title -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="jobtitle">
                                Job Title
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.jobtitle"
                                id="jobtitle"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- Sports and Hobbies -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- Sports -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="sports">
                                Sports
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.sports"
                                id="sports"
                                type="text"
                                required
                            >
                        </div>

                        <!-- Hobbies -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="hobbies">
                                Hobbies
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.hobbies"
                                id="hobbies"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- English Level and Languages -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <!-- English Level -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="english">
                                English Level
                            </label>
                            <div class="relative">
                                <select
                                    class="block appearance-none w-full border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    v-model="profile.english"
                                    id="english"
                                    required
                                >
                                    <option value="">Select Level</option>
                                    <option>Beginner</option>
                                    <option>Intermediate</option>
                                    <option>Proficient</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <!-- Languages -->
                        <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="languages">
                                Languages
                            </label>
                            <input
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.languages"
                                id="languages"
                                type="text"
                                required
                            >
                        </div>
                    </div>

                    <!-- Self Description -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="description">
                                Self Description
                            </label>
                            <textarea
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.description"
                                id="description"
                                rows="4"
                                required
                            ></textarea>
                        </div>
                    </div>

                    <!-- Comments -->
                    <div class="flex flex-wrap -mx-3 mb-6">
                        <div class="w-full px-3 mb-6 md:mb-0">
                            <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="comment">
                                Comment
                            </label>
                            <textarea
                                class="appearance-none block w-full border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                v-model="profile.comment"
                                id="comment"
                                rows="3"
                                required
                            ></textarea>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="flex flex-wrap -mx-3 mb-6 justify-center">
                        <button
                            type="submit"
                            :disabled="processing"
                            class="bg-connectyed-button-light text-connectyed-button-dark hover:bg-connectyed-button-hover-light hover:text-connectyed-button-hover-dark py-3 px-10 rounded"
                        >
                            SAVE
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Profile",
    data() {
        return {
            csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            authorization: this.$store.state.auth.authorization,
            isFormVisible: false,
            processing: false,
            userImages: [],
            uploadedImages: [],
            currentAvatar: 'upload/images/profiles/default.png',
        };
    },
    computed: {
        user() {
            return this.$store.getters['auth/user'];
        },
        profile() {
            return this.user ? this.user.profile : null;
        },
    },
    mounted() {
        this.showUserImages();
        this.getProfile();
    },
    methods: {
        toggleFormVisibility() {
            this.isFormVisible = !this.isFormVisible;
        },
        async postProfile() {
            this.processing = true;
            try {
                axios.defaults.headers.common['Authorization'] = `Bearer ${this.authorization.token}`;
                const response = await axios.put('/api/profile/update', {
                    user: this.user,
                    profile: this.profile
                });
                // Update Vuex store with new data
                this.$store.commit('auth/SET_USER', response.data.data.user);
                this.$store.commit('auth/SET_PROFILE', response.data.data.profile);
                this.isFormVisible = false;
                alert('Profile updated successfully');
            } catch (error) {
                console.error(error);
                alert('Failed to update profile.');
            } finally {
                this.processing = false;
            }
        },
        async showUserImages() {
            this.processing = true;
            try {
                axios.defaults.headers.common['Authorization'] = `Bearer ${this.authorization.token}`;
                const response = await axios.get('/api/profile/images');
                this.userImages = Object.values(response.data.data);
            } catch (error) {
                console.error(error);
                alert('Failed to fetch user images.');
            } finally {
                this.processing = false;
            }
        },
        async uploadFile(event) {
            const file = event.target.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append("file", file);
            formData.append("user_id", this.user.id);
            this.processing = true;
            try {
                axios.defaults.headers.common['Authorization'] = `Bearer ${this.authorization.token}`;
                const response = await axios.post('/api/profile/uploadimages', formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
                this.userImages.push(`/${response.data.data}`);
                alert('Image uploaded successfully');
            } catch (error) {
                console.error(error);
                alert('Failed to upload image.');
            } finally {
                this.processing = false;
            }
        },
        async updateAvatar(image) {
            this.processing = true;
            try {
                axios.defaults.headers.common['Authorization'] = `Bearer ${this.authorization.token}`;
                const response = await axios.put('/api/profile/updateavatar', {
                    avatar: image,
                });
                this.currentAvatar = response.data.data;
                // Optionally update Vuex store if avatar is part of user/profile
                this.$store.commit('auth/SET_PROFILE', { ...this.profile, avatar: response.data.data });
                alert('Avatar updated successfully');
            } catch (error) {
                console.error(error);
                alert('Failed to update avatar.');
            } finally {
                this.processing = false;
            }
        },
        async getProfile() {
            this.processing = true;
            try {
                axios.defaults.headers.common['Authorization'] = `Bearer ${this.authorization.token}`;
                const response = await axios.get('/api/profile/getprofile');
                if (response.data.data && response.data.data.avatar) {
                    this.currentAvatar = response.data.data.avatar;
                } else if (this.profile && this.profile.avatar) {
                    this.currentAvatar = this.profile.avatar;
                } else {
                    this.currentAvatar = 'upload/images/profiles/default.png';
                }
                // Update Vuex store with fetched profile
                this.$store.commit('auth/SET_PROFILE', response.data.data);
            } catch (error) {
                console.error(error);
                alert('Failed to fetch profile.');
            } finally {
                this.processing = false;
            }
        }
    },
};
</script>
