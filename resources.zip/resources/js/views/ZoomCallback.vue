<template>
    <div>
      <h4>Processing Zoom Callback...</h4>
    </div>
  </template>

  <script>
  export default {
    created() {
      // No need to process anything here; the backend will handle it.
    },
  };
  </script>
