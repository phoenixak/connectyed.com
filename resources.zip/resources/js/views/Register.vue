<!-- resources/js/views/Register.vue -->

<template>
    <div class="max-w-lg mx-auto p-4 bg-white relative">
        <h2 class="text-xl font-semibold mb-4">
            {{ form.ismatchmaker ? 'Matchmaker Registration' : 'Client Registration' }}
        </h2>

        <!-- Display Success Message -->
        <div v-if="successMessage" class="bg-green-200 text-green-800 p-4 mt-4 rounded">
            {{ successMessage }}
        </div>

        <!-- Display General Errors -->
        <div v-if="errors.general" class="bg-red-200 text-red-800 p-4 mt-4 rounded">
            {{ errors.general }}
        </div>

        <!-- Display Validation Errors -->
        <div v-if="validationErrorsList.length" class="bg-red-200 text-red-800 p-4 mt-4 rounded">
            <ul>
                <li v-for="(error, index) in validationErrorsList" :key="index">
                    {{ error }}
                </li>
            </ul>
        </div>

        <!-- Matchmaker Switch -->
        <div class="font-bold text-xl mb-2">
            <div class="relative">
                <label class="flex items-center cursor-pointer mb-4 bg-orange-50 py-2 px-1 rounded-xl">
                    <!-- Switch Container -->
                    <div class="relative">
                        <!-- Hidden checkbox input -->
                        <input
                            type="checkbox"
                            v-model="form.ismatchmaker"
                            class="sr-only"
                            @click="switchMatchmaker"
                        />

                        <!-- Switch background -->
                        <div
                            :class="{
                                'bg-connectyed-button-light': !form.ismatchmaker,
                                'bg-connectyed-button-dark': form.ismatchmaker
                            }"
                            class="block w-14 h-8 rounded-full transition-colors duration-300"
                        ></div>

                        <!-- Switch handle -->
                        <div
                            class="dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform duration-300"
                            :class="{ 'translate-x-6': form.ismatchmaker }"
                        ></div>
                    </div>
                    <span class="ml-3 text-gray-700 text-base uppercase">
                        {{ form.ismatchmaker ? 'Switch to Register as a Client' : 'Switch to Register as a Matchmaker' }}
                    </span>
                </label>
            </div>
            <span class="float-right" v-if="processing">
                <img class="h-5 ml-3" src="assets/images/icons/process.gif" alt="Processing..." />
            </span>
        </div>

        <!-- Step Indicator -->
        <div class="flex items-center mb-6" v-if="!form.ismatchmaker">
            <div v-for="(step, index) in steps" :key="index">
                <div
                    @click="goToStep(step)"
                    class="text-center py-2 px-3 mx-1 rounded-full cursor-pointer"
                    :class="{
                        'bg-connectyed-button-light text-connectyed-button-dark': currentStep === step,
                        'bg-gray-200 text-gray-600': currentStep !== step
                    }"
                >
                    {{ step }}
                </div>
            </div>
        </div>

        <form @submit.prevent="register">
            <!-- Form Steps -->
            <!-- Step 1: Account Information -->
            <div v-if="currentStep === 1">
                <h3 class="font-semibold text-lg mb-4">Account Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                    <input-text
                        label="Name"
                        v-model="form.name"
                        :required="true"
                        :error="errors.name"
                        maxlength="255"
                    />
                    <input-text
                        label="Username"
                        v-model="form.username"
                        :required="true"
                        :error="errors.username"
                        maxlength="50"
                    />
                    <input-text
                        label="Email"
                        v-model="form.email"
                        :required="true"
                        :error="errors.email"
                        maxlength="255"
                        type="email"
                    />
                    <input-text
                        label="Password"
                        type="password"
                        v-model="form.password"
                        :required="true"
                        :error="errors.password"
                        maxlength="100"
                    />
                    <input-text
                        label="Confirm Password"
                        type="password"
                        v-model="form.password_confirmation"
                        :required="true"
                        :error="errors.password_confirmation"
                        maxlength="100"
                    />
                </div>
            </div>

            <!-- Step 2: Location Details -->
            <div v-if="currentStep === 2">
                <h3 class="font-semibold text-lg mb-4">Location Details</h3>
                <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                    <input-text
                        label="City"
                        v-model="form.city"
                        :required="true"
                        :error="errors.city"
                        maxlength="100"
                    />
                    <input-text
                        label="State"
                        v-model="form.state"
                        :required="true"
                        :error="errors.state"
                        maxlength="100"
                    />
                    <select-option
                        label="Country"
                        :options="countries"
                        v-model="form.country"
                        :required="true"
                        :error="errors.country"
                    />
                    <input-text
                        label="Current Location (City)"
                        v-model="form.currentLocation"
                        :required="true"
                        :error="errors.currentLocation"
                        maxlength="100"
                    />
                </div>
            </div>

            <!-- Step 3: Personal Information (Updated for Numeric Fields) -->
            <div v-if="currentStep === 3">
                <h3 class="font-semibold text-lg mb-4">Personal Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                    <input-text
                        label="Age"
                        v-model="form.age"
                        type="number"
                        :required="true"
                        :error="errors.age"
                        maxlength="3"
                        min="1"
                        max="120"
                    />
                    <select-option
                        label="Gender"
                        :options="genders"
                        v-model="form.gender"
                        :required="true"
                        :error="errors.gender"
                    />
                    <input-text
                        label="Hair Color"
                        v-model="form.hairColor"
                        :required="true"
                        :error="errors.hairColor"
                        maxlength="50"
                    />
                    <select-option
                        label="Body Type"
                        :options="bodyTypes"
                        v-model="form.bodyType"
                        :required="true"
                        :error="errors.bodyType"
                    />
                    <div class="flex gap-4">
                        <input-text
                            label="Height (Feet)"
                            v-model="form.heightFeet"
                            type="number"
                            :required="true"
                            :error="errors.heightFeet"
                            maxlength="2"
                            min="1"
                            max="8"
                        />
                        <input-text
                            label="Inches"
                            v-model="form.heightInches"
                            type="number"
                            :required="true"
                            :error="errors.heightInches"
                            maxlength="2"
                            min="0"
                            max="11"
                        />
                    </div>
                </div>
            </div>

            <!-- Step 4: Lifestyle Information -->
            <div v-if="currentStep === 4">
                <h3 class="font-semibold text-lg mb-4">Lifestyle Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                    <select-option
                        label="Marital Status"
                        :options="maritalStatuses"
                        v-model="form.maritalStatus"
                        :required="true"
                        :error="errors.maritalStatus"
                    />
                    <select-option
                        label="Children"
                        :options="childrenOptions"
                        v-model="form.children"
                        :required="true"
                        :error="errors.children"
                    />
                    <select-option
                        label="Religion"
                        :options="religions"
                        v-model="form.religion"
                        :required="true"
                        :error="errors.religion"
                    />
                    <select-option
                        label="Smoker"
                        :options="yesNoOptions"
                        v-model="form.smoker"
                        :required="true"
                        :error="errors.smoker"
                    />
                    <select-option
                        label="Drinker"
                        :options="drinkerOptions"
                        v-model="form.drinker"
                        :required="true"
                        :error="errors.drinker"
                    />
                </div>
            </div>

            <!-- Step 5: Professional and Hobbies -->
            <div v-if="currentStep === 5">
                <h3 class="font-semibold text-lg mb-4">Professional and Hobbies</h3>
                <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                    <input-text
                        label="Education"
                        v-model="form.education"
                        :required="true"
                        :error="errors.education"
                        maxlength="100"
                    />
                    <input-text
                        label="Job Title"
                        v-model="form.jobTitle"
                        :required="true"
                        :error="errors.jobTitle"
                        maxlength="100"
                    />
                    <input-text
                        label="Sports"
                        v-model="form.sports"
                        :required="true"
                        :error="errors.sports"
                        maxlength="100"
                    />
                    <input-text
                        label="Hobbies"
                        v-model="form.hobbies"
                        :required="true"
                        :error="errors.hobbies"
                        maxlength="100"
                    />
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <select-option
                        label="English Level"
                        :options="englishLevels"
                        v-model="form.englishLevel"
                        :required="true"
                        :error="errors.englishLevel"
                    />
                    <input-text
                        label="Languages"
                        v-model="form.languages"
                        :required="true"
                        :error="errors.languages"
                        maxlength="100"
                    />
                </div>
            </div>

            <!-- Step 6: Terms and Privacy -->
            <div v-if="currentStep === 6">
                <h3 class="font-semibold text-lg mb-4">Terms and Conditions</h3>
                <div class="space-y-4 flex items-start">
                    <label class="text-gray-500 text-sm mb-2 flex items-center">
                        <input
                            type="checkbox"
                            v-model="form.privacypolicy"
                            id="privacypolicy"
                            name="privacypolicy"
                            :required="true"
                            class="mr-2"
                        />
                        <span class="text-lg">I have read and agree to the</span>
                    </label>
                    <a
                        @click="showPrivacy()"
                        class="text-connectyed-link-dark cursor-pointer underline"
                    >
                        Privacy Policy
                    </a>
                </div>
                <div class="space-y-4 flex items-start mt-2">
                    <label class="text-gray-500 text-sm mb-2 flex items-center">
                        <input
                            type="checkbox"
                            v-model="form.termsofuse"
                            id="termsofuse"
                            name="termsofuse"
                            :required="true"
                            class="mr-2"
                        />
                        <span class="text-lg">I have read and agree to the</span>
                    </label>
                    <a
                        @click="showTerm()"
                        class="text-connectyed-link-dark cursor-pointer underline"
                    >
                        Terms of Use
                    </a>
                </div>
            </div>

            <!-- Navigation Buttons -->
            <div class="mt-6 flex justify-between">
                <button
                    v-if="currentStep > 1"
                    type="button"
                    class="bg-connectyed-button-pagination-light text-connectyed-button-dark py-2 px-4 rounded min-w-32 cursor-pointer"
                    @click="prevStep"
                >
                    Previous
                </button>
                <div class="flex-1"></div>
                <button
                    v-if="currentStep < steps.length"
                    type="button"
                    class="bg-connectyed-button-pagination-light text-connectyed-button-dark py-2 px-4 rounded min-w-32 cursor-pointer"
                    @click="nextStep"
                >
                    Next
                </button>
                <button
                    v-else
                    class="bg-connectyed-button-light hover:bg-connectyed-button-hover-light text-connectyed-button-hover-dark py-2 px-4 rounded cursor-pointer"
                    type="submit"
                    :disabled="processing"
                >
                    {{ processing ? "Please wait" : "Register" }}
                </button>
            </div>
        </form>

        <label class="my-4 w-full block text-center">
            Already have an account?
            <router-link class="text-connectyed-link-dark underline" :to="{ name: 'login' }">Login Now!</router-link>
        </label>

        <pdf-modal :isOpen="isModalOpen" :pdfUrl="pdfUrl" @close="closeModal" />
    </div>
</template>

<script>
import { mapActions } from 'vuex';
import PdfModal from '../components/PdfModal.vue';
import InputText from '../components/InputText.vue';
import SelectOption from '../components/SelectOption.vue';

export default {
    name: "Register",
    components: {
        InputText,
        SelectOption,
        PdfModal,
    },
    data() {
        return {
            currentStep: 1,
            steps: [1, 2, 3, 4, 5, 6],
            form: {
                name: "",
                username: "",
                email: "",
                password: "",
                password_confirmation: "",
                city: "",
                state: "",
                country: "",
                currentLocation: "",
                age: "",
                gender: "",
                hairColor: "",
                bodyType: "",
                heightFeet: "",
                heightInches: "",
                maritalStatus: "",
                children: "",
                religion: "",
                smoker: "", // Will convert to boolean
                drinker: "",
                education: "",
                jobTitle: "",
                sports: "",
                hobbies: "",
                englishLevel: "",
                languages: "",
                privacypolicy: false,
                termsofuse: false,
                ismatchmaker: false
            },
            errors: {},
            countries: ['United States of America', 'Canada'],
            genders: ['Male', 'Female'],
            bodyTypes: ['Slender', 'Average', 'Athletic', 'Curvy', 'Big and Beautiful'],
            maritalStatuses: ['Single', 'Separated', 'Divorced'],
            childrenOptions: ['0', '1', '2', '3', '4'],
            religions: [
                'Buddhism', 'Catholic', 'Christian', 'Confucianism', 'Hinduism',
                'Islam', 'Jainism', 'Judaism', 'Shinto', 'Sikhism',
                'Taoism', 'Zoroastrianism', 'Other'
            ],
            yesNoOptions: ['Yes', 'No'],
            drinkerOptions: ['None', 'Occasionally', 'Often'],
            englishLevels: ['Beginner', 'Intermediate', 'Proficient'],
            successMessage: '',
            validationErrors: {},
            isModalOpen: false,
            pdfUrl: '',
            modalMode: {
                header: "",
            },
            processing: false
        };
    },
    computed: {
        validationErrorsList() {
            // Extract all validation errors except 'general'
            return Object.keys(this.errors)
                .filter(key => this.errors[key] && key !== 'general')
                .map(key => this.errors[key]);
        }
    },
    methods: {
        ...mapActions({
            registerUser: 'auth/register'
        }),
        nextStep() {
            this.clearErrors();
            let hasError = false;

            // Validate current step fields
            switch (this.currentStep) {
                case 1:
                    if (!this.form.name) {
                        this.errors.name = 'Name is required';
                        hasError = true;
                    }
                    if (!this.form.username) {
                        this.errors.username = 'Username is required';
                        hasError = true;
                    }
                    if (!this.form.email) {
                        this.errors.email = 'Email is required';
                        hasError = true;
                    } else if (!this.validateEmail(this.form.email)) {
                        this.errors.email = 'Please enter a valid email';
                        hasError = true;
                    }
                    if (!this.form.password) {
                        this.errors.password = 'Password is required';
                        hasError = true;
                    } else if (this.form.password.length < 6) {
                        this.errors.password = 'Password must be at least 6 characters';
                        hasError = true;
                    }
                    if (!this.form.password_confirmation) {
                        this.errors.password_confirmation = 'Password confirmation is required';
                        hasError = true;
                    } else if (this.form.password !== this.form.password_confirmation) {
                        this.errors.password_confirmation = 'Passwords do not match';
                        hasError = true;
                    }
                    break;
                case 2:
                    if (!this.form.city) {
                        this.errors.city = 'City is required';
                        hasError = true;
                    }
                    if (!this.form.state) {
                        this.errors.state = 'State is required';
                        hasError = true;
                    }
                    if (!this.form.country) {
                        this.errors.country = 'Country is required';
                        hasError = true;
                    }
                    if (!this.form.currentLocation) {
                        this.errors.currentLocation = 'Current Location is required';
                        hasError = true;
                    }
                    break;
                case 3:
                    if (!this.form.age) {
                        this.errors.age = 'Age is required';
                        hasError = true;
                    } else if (isNaN(this.form.age) || this.form.age <= 0 || this.form.age > 120) {
                        this.errors.age = 'Please enter a valid age';
                        hasError = true;
                    }

                    if (!this.form.gender) {
                        this.errors.gender = 'Gender is required';
                        hasError = true;
                    }
                    if (!this.form.hairColor) {
                        this.errors.hairColor = 'Hair Color is required';
                        hasError = true;
                    }
                    if (!this.form.bodyType) {
                        this.errors.bodyType = 'Body Type is required';
                        hasError = true;
                    }
                    if (!this.form.heightFeet) {
                        this.errors.heightFeet = 'Height in Feet is required';
                        hasError = true;
                    } else if (isNaN(this.form.heightFeet) || this.form.heightFeet <= 0 || this.form.heightFeet > 8) {
                        this.errors.heightFeet = 'Please enter a valid height in feet';
                        hasError = true;
                    }
                    if (this.form.heightInches === '' || this.form.heightInches === null) {
                        this.errors.heightInches = 'Inches is required';
                        hasError = true;
                    } else if (isNaN(this.form.heightInches) || this.form.heightInches < 0 || this.form.heightInches >= 12) {
                        this.errors.heightInches = 'Please enter a valid number of inches';
                        hasError = true;
                    }
                    break;
                case 4:
                    if (!this.form.maritalStatus) {
                        this.errors.maritalStatus = 'Marital Status is required';
                        hasError = true;
                    }
                    if (this.form.children === '' || this.form.children === null) {
                        this.errors.children = 'Children is required';
                        hasError = true;
                    }
                    if (!this.form.religion) {
                        this.errors.religion = 'Religion is required';
                        hasError = true;
                    }
                    if (this.form.smoker === '') {
                        this.errors.smoker = 'Smoker status is required';
                        hasError = true;
                    }
                    if (!this.form.drinker) {
                        this.errors.drinker = 'Drinker status is required';
                        hasError = true;
                    }
                    break;
                case 5:
                    if (!this.form.education) {
                        this.errors.education = 'Education is required';
                        hasError = true;
                    }
                    if (!this.form.jobTitle) {
                        this.errors.jobTitle = 'Job Title is required';
                        hasError = true;
                    }
                    if (!this.form.sports) {
                        this.errors.sports = 'Sports is required';
                        hasError = true;
                    }
                    if (!this.form.hobbies) {
                        this.errors.hobbies = 'Hobbies is required';
                        hasError = true;
                    }
                    if (!this.form.englishLevel) {
                        this.errors.englishLevel = 'English Level is required';
                        hasError = true;
                    }
                    if (!this.form.languages) {
                        this.errors.languages = 'Languages is required';
                        hasError = true;
                    }
                    break;
                case 6:
                    if (!this.form.privacypolicy) {
                        this.errors.general = 'You must agree to the Privacy Policy';
                        hasError = true;
                    }
                    if (!this.form.termsofuse) {
                        this.errors.general = 'You must agree to the Terms of Use';
                        hasError = true;
                    }
                    break;
                default:
                    break;
            }

            if (!hasError) {
                const currentStepIndex = this.steps.indexOf(this.currentStep);
                if (currentStepIndex < this.steps.length - 1) {
                    this.currentStep = this.steps[currentStepIndex + 1];
                }
            }
        },
        prevStep() {
            const currentStepIndex = this.steps.indexOf(this.currentStep);
            if (currentStepIndex > 0) {
                this.currentStep = this.steps[currentStepIndex - 1];
            }
        },
        switchMatchmaker() {
            this.form.ismatchmaker = !this.form.ismatchmaker;
            if (this.form.ismatchmaker) {
                this.steps = [1, 2, 6];
            } else {
                this.steps = [1, 2, 3, 4, 5, 6];
            }

            // Reset currentStep if it's not in the new steps array
            if (!this.steps.includes(this.currentStep)) {
                this.currentStep = 1;
            }

            // Optionally, clear errors and form data specific to steps that are no longer visible
            this.clearErrors();
        },
        goToStep(number) {
            if (this.steps.includes(number)) {
                this.currentStep = number;
            }
        },
        showPrivacy() {
            this.modalMode.header = "Privacy Policy";
            this.pdfUrl = "/upload/pdf/privacypolicy.pdf";
            this.isModalOpen = true;
        },
        showTerm() {
            this.modalMode.header = "Terms of Use Agreement";
            this.pdfUrl = "/upload/pdf/termsofuse.pdf";
            this.isModalOpen = true;
        },
        closeModal() {
            this.isModalOpen = false;
            this.pdfUrl = '';
        },
        async register() {
    this.processing = true;
    this.clearErrors(); // Clear previous errors
    this.successMessage = ''; // Clear previous success messages

    // Create a copy of the form data to modify
    let formData = { ...this.form };

    // Convert 'smoker' from 'Yes'/'No' to boolean
    formData.smoker = formData.smoker === 'Yes' ? true : false;

    // Convert 'children' from string to integer
    formData.children = parseInt(formData.children, 10);

    // Convert 'age', 'heightFeet', 'heightInches' to integers
    formData.age = parseInt(formData.age, 10);
    formData.heightFeet = parseInt(formData.heightFeet, 10);
    formData.heightInches = parseInt(formData.heightInches, 10);

    // Ensure 'termsofuse' and 'privacypolicy' are booleans (from checkboxes)
    formData.termsofuse = !!formData.termsofuse;
    formData.privacypolicy = !!formData.privacypolicy;

    try {
        const response = await this.registerUser(formData);
        if (response.success === true) {
            this.successMessage = response.message;
            this.validationErrors = {};
            setTimeout(() => {
                this.$router.push({ name: "login" });
            }, 1500);
        }
    } catch (error) {
        if (error.response && error.response.status === 422) {
            this.validationErrors = error.response.data.errors || error.response.data.message;
            this.mapValidationErrors();
        } else if (error.response && error.response.status === 500) {
            this.errors.general = 'Server error. Please try again later.';
        } else {
            this.errors.general = error.response.data.message || 'An unexpected error occurred.';
        }
    } finally {
        this.processing = false;
    }
},
        mapValidationErrors() {
            for (const [key, messages] of Object.entries(this.validationErrors)) {
                if (this.errors.hasOwnProperty(key)) {
                    this.errors[key] = messages[0]; // Display the first error message
                } else {
                    // Handle general errors
                    this.errors.general = messages[0];
                }
            }
        },
        clearErrors() {
            this.errors = {};
        },
        validateEmail(email) {
            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\\.,;:\s@"]+\.)+[^<>()[\]\\.,;:\s@"]{2,})$/i;
            return re.test(String(email).toLowerCase());
        }
    },
};
</script>

<style scoped>
/* Component-specific styles */

/* Switch Handle */
.dot {
    transition: transform 0.3s;
}

/* Error Message Styles */
.bg-red-200 {
    background-color: #fee2e2;
}
.text-red-800 {
    color: #991b1b;
}

/* Success Message Styles */
.bg-green-200 {
    background-color: #d1fae5;
}
.text-green-800 {
    color: #065f46;
}

/* Optional: Add custom styles for error messages or other elements if needed */
</style>
