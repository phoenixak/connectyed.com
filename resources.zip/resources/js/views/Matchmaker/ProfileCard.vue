<template>
    <div class="">
      <!-- Card Start -->
      <div class="max-w-sm mx-auto bg-white rounded-lg shadow-sm">
        <!-- User Name -->
        <h4 class="p-2 uppercase text-center text-sm text-gray-600 dark:text-white mb-1">
          {{ matchmaker.name }}
        </h4>

        <!-- Avatar and Clients -->
        <div class="border-b">
          <!-- User Avatar -->
          <div class="text-center">
            <div class="w-[384px] h-[384px] overflow-hidden bg-gray-400">
              <img :src="matchmaker.profile.avatar || '/upload/images/profiles/default.png'" :alt="matchmaker.name" class="w-full h-full object-cover">
            </div>
          </div>

          <!-- Clients' Avatars (Optional) -->
          <!--
          <div class="flex justify-center items-center flex-wrap mt-2" v-if="matchmaker.clients && matchmaker.clients.length > 0">
            <div v-for="client in matchmaker.clients" :key="client.id" class="w-[25%] p-1">
              <a :href="'/' + client.username">
                <img
                  class="border-2 border-white dark:border-gray-800 rounded-full w-16 h-16 object-cover"
                  :src="client.avatar || '/upload/images/profiles/default.png'"
                  :alt="client.name"
                />
              </a>
            </div>
          </div>
          -->

          <!-- Location -->
          <div class="py-2 flex justify-center items-center">
            <div class="inline-flex text-gray-700 dark:text-gray-300 items-center">
              <svg class="h-5 w-5 text-gray-400 dark:text-gray-600 mr-1" fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                <path
                    d="M5.64 16.36a9 9 0 1 1 12.72 0l-5.65 5.66a1 1 0 0 1-1.42 0l-5.65-5.66zm11.31-1.41a7 7 0 1 0-9.9 0L12 19.9l4.95-4.95zM12 14a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-2a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
              </svg>
              {{ matchmaker.profile.location }}
            </div>
          </div>
        </div>

        <!-- Availability Section -->
        <div class="mt-4">
          <div class="text-center font-bold p-1">Availability</div>
          <ul class="mt-2 space-y-2">
            <li v-for="(slot) in matchmaker.availability" :key="slot.id" class="">
              <div class="grid grid-cols-1 p-1 text-center">
                <div class="bg-connectyed-card-light p-1 rounded-md">
                  {{ formatDate(slot.start_date) }} - {{ formatDate(slot.end_date) }}
                </div>
                <div v-if="slot.start_time" class="rounded text-center text-sm font-bold">
                  {{ formatTime(slot.start_time) }} - {{ formatTime(slot.end_time) }}
                </div>
              </div>
            </li>
          </ul>
        </div>

        <!-- Specialties Section -->
        <div class="mt-4">
          <div class="text-center font-bold p-1">Specialties</div>
          <div v-if="matchmaker.specialties">
            <!-- Age Range -->
            <div v-if="matchmaker.specialties.minage || matchmaker.specialties.maxage" class="text-center font-semibold bg-connectyed-card-light p-1 rounded-md">Age Range</div>
            <p v-if="matchmaker.specialties.minage || matchmaker.specialties.maxage" class="text-center">
              {{ matchmaker.specialties.minage || 'N/A' }} - {{ matchmaker.specialties.maxage || 'N/A' }} years
            </p>

            <!-- Gender Preferences -->
            <div v-if="matchmaker.specialties.gender" class="mt-2 text-center font-bold bg-connectyed-card-light p-1 rounded-md">Gender Preferences</div>
            <p v-if="matchmaker.specialties.gender" class="text-center">
              {{ formatGender(matchmaker.specialties.gender) }}
            </p>

            <!-- Locations -->
            <div v-if="matchmaker.specialties.locations && parsedLocations.length > 0" class="mt-2 text-center font-bold bg-connectyed-card-light p-1 rounded-md">Locations</div>
            <ul v-if="matchmaker.specialties.locations && parsedLocations.length > 0" class="list-disc list-inside">
              <li class="text-center" v-for="location in parsedLocations" :key="location.id">
                {{ location.name }} ({{ location.category }})
              </li>
            </ul>
          </div>
          <div v-else class="text-center">No specialties defined.</div>
        </div>
      </div>
      <!-- Card End -->
    </div>
  </template>

  <script>
  import moment from 'moment-timezone';

  export default {
    props: {
      matchmaker: {
        type: Object,
        required: true,
        default: () => ({
          name: '',
          username: '',
          profile: {
            location: '',
            avatar: '/upload/images/profiles/default.png',
          },
          specialties: null,
          availability: [],
          // Add other default fields as necessary
        }),
      },
    },
    computed: {
      // Parses the locations string into an array of location objects
      parsedLocations() {
        if (!this.matchmaker.specialties || !this.matchmaker.specialties.locations) return [];
        // Assuming locations are stored as JSON string or comma-separated values with categories
        // Example: [{"name": "New York", "category": "City"}, {"name": "California", "category": "State"}]
        try {
          const locationsData = this.matchmaker.specialties.locations;
          // Handle cases where locations are an empty array represented as "[]"
          if (locationsData === '[]') return [];
          return JSON.parse(locationsData);
        } catch (e) {
          // Fallback if locations are comma-separated strings without categories
          return this.matchmaker.specialties.locations.split(',').map((loc, index) => ({
            id: index,
            name: loc.trim(),
            category: 'N/A', // Default category if not provided
          }));
        }
      },
    },
    methods: {
      formatDate(date) {
        if (!date) return 'N/A';
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(date).toLocaleDateString(undefined, options);
      },
      formatTime(time) {
        if (!time) return 'N/A';
        return moment(time, "HH:mm:ss").format("h:mm A");
      },
      formatGender(gender) {
        const genders = {
          male: 'Male',
          female: 'Female',
          male_female: 'Male & Female',
          other: 'Other',
        };
        return genders[gender] || 'Unspecified';
      },
    },
  };
  </script>

  <style scoped>
  /* Add any additional styles if necessary */
  /* Example: Adjust image sizes for responsiveness */
  img {
    transition: transform 0.3s;
  }
  img:hover {
    transform: scale(1.05);
  }
  </style>
