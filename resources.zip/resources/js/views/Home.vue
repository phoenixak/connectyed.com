<template>
    <!-- ================> Banner section start here <================== -->
    <div class="banner banner--style2 padding-top bg_img">
      <div class="container">
        <div class="banner__wrapper">
          <div class="row g-0 justify-content-center">
            <div class="col-lg-4 col-12">
              <div class="banner__content wow fadeInLeft" data-wow-duration="1.5s">
                <div class="banner__title">
                  <h2>Find Your Perfect Match. v1</h2>
                  <p>At Connectyed, we understand the challenges of finding meaningful connections in a busy world. Our mission is to make your search for the perfect match as effortless and rewarding as possible.</p>
                    <router-link :to="{ name: 'register' }" class="bg-connectyed-button-light text-connectyed-button-dark hover:bg-connectyed-button-hover-light hover:text-connectyed-button-dark py-4 px-5">
                        Free matchmaking until 9/18
                    </router-link>
                </div>
              </div>
            </div>
            <div class="col-lg-8 col-12">
              <div class="banner__thumb wow fadeInUp" data-wow-duration="1.5s">
                <img src="assets/images/banner/pexels-orione-conceicao-1531154-2983449.png" alt="Banner Image">
                <div class="banner__thumb--shape">
                  <div class="shapeimg shapeimg__one">
                    <img src="assets/images/banner/shape/home2/01.png" alt="Shape Image One">
                  </div>
                  <div class="shapeimg shapeimg__two">
                    <img src="assets/images/banner/shape/home2/02.png" alt="Shape Image Two">
                  </div>
                  <div class="shapeimg shapeimg__three">
                    <img src="assets/images/banner/shape/home2/03.png" alt="Shape Image Three">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ================> Banner section end here <================== -->

    <!-- Matchmakers Carousel section start here -->
    <div class="matchmakers padding-bottom bg_img">
      <div class="container">
        <div class="section__header style-2 text-center">
          <h2>Our Matchmakers</h2>
          <p>Choose from our qualified matchmakers to find your perfect match.</p>
        </div>
        <div class="section__wrapper">
          <!-- Swiper Component -->
          <Swiper
            :modules="[Navigation, Pagination]"
            :spaceBetween="30"
            :slidesPerView="3"
            navigation
            :pagination="{ clickable: true }"
            :breakpoints="{
              320: { slidesPerView: 1, spaceBetween: 10 },
              640: { slidesPerView: 2, spaceBetween: 20 },
              1024: { slidesPerView: 3, spaceBetween: 30 }
            }"
            class="mySwiper"
          >
            <SwiperSlide v-for="matchmaker in matchmakers" :key="matchmaker.id">
              <ProfileCard :matchmaker="matchmaker" />
            </SwiperSlide>
            <!-- Optionally, you can add additional SwiperSlide components here -->
          </Swiper>
        </div>
      </div>
    </div>
    <!-- Matchmakers Carousel section end here -->

    <!-- Story section start here -->
    <!--<div class="story bg_img padding-top padding-bottom">-->
    <!--  <div class="container">-->
    <!--    <div class="section__header style-2 text-center wow fadeInUp" data-wow-duration="1.5s">-->
    <!--      <h2>Dating Tips</h2>-->
    <!--    </div>-->
    <!--    <div class="section__wrapper">-->
    <!--      <div class="row g-4 justify-content-center row-cols-lg-3 row-cols-sm-2 row-cols-1">-->
    <!--        <div class="col wow fadeInUp" data-wow-duration="1.5s" v-for="(post, index) in featuredPosts.data" :key="index">-->
    <!--          <div class="story__item">-->
    <!--            <div class="story__inner">-->
    <!--              <div class="story__thumb">-->
    <!--                <a :href="post.slug"><img :src="post.image" alt="Story Image"></a>-->
    <!--              </div>-->
    <!--              <div class="story__content">-->
    <!--                <a :href="post.slug" class="text-"><h4 class="h-20">{{ post.title }}</h4></a>-->
    <!--              </div>-->
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
<section class="bg-light-gray py-10 px-6 text-center">
    <!-- Title and Subtitle -->
    <h2 class="text-3xl font-bold text-dark-blue">Dating Tips</h2>
    <p class="text-gray-600 mt-2">Simple Steps to Boost Your Dating Confidence</p>
    
    <!-- Content Section -->
    <div class="flex flex-col md:flex-row justify-center items-center mt-8 space-x-4">
        <!-- Images -->
        <div class="flex space-x-4">
            <img src="assets/images/banner/pexels-orione-conceicao-1531154-2983449.png" alt="Person smiling with sunglasses" class="rounded-lg shadow-lg w-32 md:w-40 h-auto">
            <img src="assets/images/banner/pexels-orione-conceicao-1531154-2983449.png" alt="Person in a casual shirt" class="rounded-lg shadow-lg w-32 md:w-40 h-auto">
        </div>

        <!-- Text Content -->
        <div class="mt-6 md:mt-0 md:ml-6 text-left">
            <h3 class="text-2xl font-semibold text-dark-blue">First Impressions Matter</h3>
            <p class="text-gray-700 mt-2">
                Your first date is all about showing the best version of yourself. Wear something you are comfortable in
                as it directly reflects your personality. Confidence is key!
            </p>
            
            <!-- Navigation Buttons -->
            <div class="flex items-center mt-4">
                <button class="bg-gray-300 text-gray-700 py-2 px-4 rounded-l-lg focus:outline-none">← Previous</button>
                <button class="bg-dark-blue text-white py-2 px-4 rounded-r-lg focus:outline-none">Next →</button>
            </div>
            <!-- Page Indicator -->
            <p class="text-gray-500 mt-2">1/5</p>
        </div>
    </div>
</section>

    <!-- Story section end here -->

    <!-- About section start here -->
    <div class="about padding-top padding-bottom bg_img">
      <div class="container">
        <div class="section__header style-2 text-center wow fadeInUp" data-wow-duration="1.5s">
          <h2>How it Works</h2>
          <p>Connectyed specializes in matchmaking for busy professionals. We offer a streamlined, personalized approach to help you connect with someone.</p>
        </div>
        <div class="section__wrapper">
          <div class="row g-4 justify-content-center row-cols-xl-4 row-cols-lg-3 row-cols-sm-2 row-cols-1">
            <div class="col wow fadeInUp" data-wow-duration="1.5s" v-for="(item, index) in howItWorks" :key="index">
              <div class="about__item text-center">
                <div class="about__inner">
                  <div class="about__thumb flex justify-center">
                    <img :src="item.image" :alt="item.altText">
                  </div>
                  <div class="about__content">
                    <h4>{{ item.title }}</h4>
                    <p>{{ item.description }}</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- Repeat similar blocks for each "How it Works" step -->
          </div>
        </div>
      </div>
    </div>
    <!-- About section end here -->
  </template>

  <script setup>
  import { onMounted, ref } from 'vue';
  import { Swiper, SwiperSlide } from 'swiper/vue';
  import { Navigation, Pagination } from 'swiper/modules'; // Updated import path for Swiper modules
  import 'swiper/swiper-bundle.css'; // Import Swiper styles

  import usePosts from "../composables/posts";
  import useMatchmakers from '../composables/matchmakers';
  import ProfileCard from './Matchmaker/ProfileCard.vue';

  const { matchmakers, getMatchmakers } = useMatchmakers();
  const { featuredPosts, getFeaturedPosts } = usePosts();

  // Define "howItWorks" data
  const howItWorks = ref([
    {
      image: 'assets/images/about/01.jpg',
      altText: 'Choose Your Matchmaker Image',
      title: 'Choose Your Matchmaker',
      description: 'Browse our curated list of qualified matchmakers, each with their own expertise and approach. Select the one who best aligns with your relationship goals and preferences.'
    },
    {
      image: 'assets/images/about/02.jpg',
      altText: 'Introduction Session Image',
      title: 'Introduction Session',
      description: 'Set up an initial introduction session with your chosen matchmaker. This is your opportunity to discuss your relationship goals and get professional advice on how to navigate the dating world.'
    },
    {
      image: 'assets/images/about/03.jpg',
      altText: 'Personalized Matchmaking Image',
      title: 'Personalized Matchmaking',
      description: 'Based on your criteria, your matchmaker will curate 1-on-1 video dates with targeted singles who meet your specifications. Enjoy meaningful connections from the comfort of your own home.'
    },
    {
      image: 'assets/images/about/04.jpg',
      altText: 'Flexible Pricing Image',
      title: 'Flexible Pricing',
      description: 'Prices vary by matchmaker, allowing you to choose a package that fits your needs and budget.'
    }
  ]);

  onMounted(async () => {
    try {
      await getFeaturedPosts();
      await getMatchmakers();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  });
  </script>

<style>
@import 'swiper/swiper-bundle.css';

/* CSS Variables for Consistent Styling */
:root {
  --connectyed-button-light: #f0f0f0;
  --connectyed-button-dark: #333333;
  --connectyed-button-hover-light: #e0e0e0;
  --connectyed-button-hover-dark: #333333; /* Changed from #ffffff for better contrast */
}

/* Button Styles */
.bg-connectyed-button-light {
  background-color: var(--connectyed-button-light);
}

.text-connectyed-button-dark {
  color: var(--connectyed-button-dark);
}

.hover\:bg-connectyed-button-hover-light:hover {
  background-color: var(--connectyed-button-hover-light);
}

.hover\:text-connectyed-button-light:hover {
  color: var(--connectyed-button-hover-dark); /* Ensures text is readable */
}

/* Specific Button Hover Fixes */
.bg-connectyed-button-light.text-connectyed-button-dark.hover\:bg-connectyed-button-hover-light.hover\:text-connectyed-button-light {
  transition: background-color 0.3s, color 0.3s;
}

button, .bg-connectyed-button-light, .bg-connectyed-button-pagination-light {
  /* Ensure all buttons have smooth transitions */
  transition: background-color 0.3s, color 0.3s;
}

/* Additional Button Hover Styles */
button:hover, .bg-connectyed-button-light:hover, .bg-connectyed-button-pagination-light:hover {
  /* Maintain text readability on hover */
  color: var(--connectyed-button-hover-dark);
}

/* Specific styles for Subscribe button in footer */
.footer__newsletter--form button:hover {
  color: var(--connectyed-button-hover-dark) !important;
}

/* Ensure all header buttons have readable text on hover */
button.bg-connectyed-button-light:hover,
a.bg-connectyed-button-light:hover {
  color: var(--connectyed-button-hover-dark) !important;
}
</style>

