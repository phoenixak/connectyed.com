    // resources/js/app.js
    import './bootstrap';
    import '../css/app.css';
    import Router from '@/router';
    import store from '@/store';
    import { createApp } from 'vue';
    import App from './App.vue'; // Import your root component

    // Initialize the store
    store.dispatch('auth/initialize').then(() => {
    const app = createApp(App); // Pass App to createApp
    app.use(Router);
    app.use(store);
    app.mount('#app');
    });
