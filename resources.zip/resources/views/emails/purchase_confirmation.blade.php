@component('mail::message')
# Thank You for Your Purchase!

Dear {{ $client->name }},

We are excited to inform you that your purchase of **{{ ucfirst($productType) }}** has been successfully processed.

@component('mail::button', ['url' => config('app.url')])
Explore Your Benefits
@endcomponent

If you have any questions or need further assistance, feel free to reach out to our support team.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
