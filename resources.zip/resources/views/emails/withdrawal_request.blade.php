<p>Dear Admin,</p>

<p>{{ $name }} ({{ $email }}) has requested a withdrawal of ${{ number_format($amount, 2) }}.</p>

<p>Please process this request accordingly.</p>

<p>Best regards,<br>
Connectyed Team</p>
