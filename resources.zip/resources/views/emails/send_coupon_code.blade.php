<p>Dear {{ $name }},</p>

<p>Thank you for scheduling a meeting with us!</p>

<p>As a special offer, here is your coupon code:</p>

<h2>{{ $couponCode }}</h2>

<p>You can use this coupon code to get a discount on our dating packages.</p>

<p>Best regards,<br>
Connectyed Team</p>
